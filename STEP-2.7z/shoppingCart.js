let shoppingCart = { totalAmount: 0 };

const roundToDecimalPlaces = (num, places) => {
  num = num.toFixed(places);
  return (num = parseFloat(num));
};
const updateCartTotal = ({ quantity, price }) => {
  let itemisedTotal = quantity * price;
  shoppingCart.totalAmount = roundToDecimalPlaces(
    shoppingCart.totalAmount + itemisedTotal,
    2
  );
};

const addOrUpdateProduct = productInfo => {
  let { name, quantity } = { ...productInfo };
  if (name in shoppingCart) {
    shoppingCart[name].quantity += quantity;
  } else {
    shoppingCart[name] = productInfo;
  }
};
const addProductToCart = productInfo => {
  updateCartTotal(productInfo);
  addOrUpdateProduct(productInfo);

  return shoppingCart;
};

export default addProductToCart;
