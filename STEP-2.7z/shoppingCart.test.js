// const sum = require("./sum");
import addProductToCart from "./shoppingCart.js";

test("adding products to the cart calculates quantity and total cart amount correctly", () => {
  let productDetails = [
    {
      name: "dove",
      quantity: 5,
      price: 39.99
    },
    {
      name: "dove",
      quantity: 3,
      price: 39.99
    },
    {
      name: "lux",
      quantity: 1,
      price: 39.99
    }
  ];
  expect(addProductToCart(productDetails[0])).toMatchObject({
    totalAmount: 199.95,
    dove: { name: "dove", quantity: 5 }
  });

  expect(addProductToCart(productDetails[1])).toMatchObject({
    totalAmount: 319.92,
    dove: { name: "dove", quantity: 8 }
  });

  expect(addProductToCart(productDetails[2])).toMatchObject({
    totalAmount: 359.91,
    dove: { name: "dove", quantity: 8 }
  });
});
