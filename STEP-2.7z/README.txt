version number 37981f84a50f54cb59378870e3f06ea1c17db7d7

Steps to run the test,

1. npm install
2. npm run test
