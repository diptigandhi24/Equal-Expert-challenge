// const sum = require("./sum");
import addProductToCart from "./shoppingCart.js";

test("Calculate the tax rate of the shopping cart with multiple items", () => {
  let productDetails = [
    {
      name: "dove",
      quantity: 2,
      price: 39.99
    },
    {
      name: "Axe Deos",
      quantity: 2,
      price: 99.99
    }
  ];

  expect(addProductToCart(productDetails[0], 12.5)).toMatchObject({
    dove: { name: "dove", quantity: 2, price: 39.99 },
    totalAmount: 79.98
  });

  expect(addProductToCart(productDetails[1], 12.5, true)).toMatchObject({
    dove: { name: "dove", quantity: 2, price: 39.99 },
    "Axe Deos": { name: "Axe Deos", quantity: 2, price: 99.99 },
    totalAmount: 314.96,
    salesTax: 35
  });
  // expect(addProductToCart(productDetails, 13.3)).toMatchObject({
  //   dove: { name: "dove", quantity: 2, price: 39.99 },
  //   "Axe Deos": { name: "Axe Deos", quantity: 2, price: 99.99 },
  //   totalAmount: 316.96,
  //   salesTax: 37
  // });
});
