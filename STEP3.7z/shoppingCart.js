let shoppingCart = { totalAmount: 0 };

const roundToDecimalPlaces = (num, places) => {
  num = num.toFixed(places);
  num = parseFloat(num);
  return num;
};
const updateCartTotal = ({ quantity, price }) => {
  let itemisedTotal = quantity * price;
  console.log("before grandTotal", shoppingCart.totalAmount);
  shoppingCart.totalAmount = roundToDecimalPlaces(
    shoppingCart.totalAmount + itemisedTotal,
    2
  );
  console.log("After grandTotal", shoppingCart.totalAmount);
};
const calcSalestax = (amount, tax) => {
  let percent = tax / 100;
  let salesTax = amount * percent;
  salesTax = Math.round(salesTax);

  return salesTax;
};
const addOrUpdateProduct = productInfo => {
  let { name, quantity } = { ...productInfo };
  if (name in shoppingCart) {
    shoppingCart[name].quantity += quantity;
  } else {
    shoppingCart[name] = productInfo;
  }
};
const addProductToCart = (
  product,
  salesTaxAmount = 12.5,
  endOfList = false
) => {
  updateCartTotal(product);
  addOrUpdateProduct(product);
  if (endOfList == true) {
    shoppingCart.salesTax = calcSalestax(
      shoppingCart.totalAmount,
      salesTaxAmount
    );
    console.log(
      "shoppingCart.totalAmount + shoppingCart.salesTax",
      shoppingCart.totalAmount,
      shoppingCart.salesTax
    );
    shoppingCart.totalAmount = shoppingCart.totalAmount + shoppingCart.salesTax;
  }
  return shoppingCart;
};

export default addProductToCart;
