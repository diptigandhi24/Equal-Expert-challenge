import addProductToCart from "./shoppingCart.js";

test("adding product to the cart and calculate total price", () => {
  let productDetails = [
    {
      name: "dove",
      quantity: 5,
      price: 39.99
    }
  ];
  expect(addProductToCart(productDetails[0])).toMatchObject({
    totalAmount: 199.95,
    dove: { name: "dove", quantity: 5, price: 39.99 }
  });
});
