let shoppingCart = { totalAmount: 0 };

const roundToDecimalPlaces = (num, places) => {
  num = num.toFixed(places);
  return (num = parseFloat(num));
};
const updateCartTotal = ({ quantity, price }) => {
  let itemisedTotal = quantity * price;
  shoppingCart.totalAmount = roundToDecimalPlaces(
    shoppingCart.totalAmount + itemisedTotal,
    2
  );
};

const addProductToCart = productInfo => {
  shoppingCart[productInfo.name] = productInfo;
  updateCartTotal(productInfo);

  return shoppingCart;
};

export default addProductToCart;
